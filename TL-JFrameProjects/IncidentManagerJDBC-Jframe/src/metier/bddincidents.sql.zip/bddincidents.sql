-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Dim 26 Juillet 2015 à 16:56
-- Version du serveur: 5.6.12-log
-- Version de PHP: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `bddincidents`
--
CREATE DATABASE IF NOT EXISTS `bddincidents` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `bddincidents`;

-- --------------------------------------------------------

--
-- Structure de la table `incidents`
--

CREATE TABLE IF NOT EXISTS `incidents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `urgence` int(11) NOT NULL,
  `categorie` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `incidents`
--

INSERT INTO `incidents` (`id`, `description`, `date`, `urgence`, `categorie`) VALUES
(1, 'panne sur h1n1', '2015-07-26', 5, 'conditionnement'),
(2, 'plus d''eau atelier', '2015-07-26', 2, 'atelier'),
(3, 'panne sur le compresseur', '2015-07-22', 4, 'fabrication'),
(4, 'neon n°53 hs', '2015-04-06', 2, 'atelier'),
(5, 'rupture de stock vis', '2015-04-16', 4, 'fabrication'),
(6, 'rupture de stock ecrou', '2015-03-10', 4, 'conditionnement'),
(7, 'rien....verin de poussée HS', '2015-01-06', 5, 'fabrication');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
