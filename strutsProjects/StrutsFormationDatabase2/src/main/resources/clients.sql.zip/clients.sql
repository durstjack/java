-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Client: 127.0.0.1
-- Généré le: Lun 27 Juillet 2015 à 11:57
-- Version du serveur: 5.5.27
-- Version de PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `webfirstjdbc`
--

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `solde` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Contenu de la table `clients`
--

INSERT INTO `clients` (`id`, `nom`, `email`, `solde`) VALUES
(2, 'franck calestroupat', 'franck.calestroupat@sfr.fr', 14),
(3, 'vincent', 'vincent.courtalon@orange.fr', 44000),
(4, 'John Doe', 'john.doe@sfr.fr', 200),
(5, 'Paul J. Morena', 'PaulJMoreno@rhyta.com', 1300),
(6, 'George M. Bowmano', 'GeorgeMBowman@armyspy.com', 145),
(7, 'Martha E. Nichols', 'MarthaENichols@jourrapide.com', 200),
(8, 'James D. McConnell', 'JamesDMcConnell@jourrapide.com', 26000),
(9, 'Ezekiel B. Munoz', 'EzekielBMunoz@teleworm.us', 169),
(10, 'Tracy F. Kolar', 'TracyFKolar@dayrep.com', 2000),
(11, 'Ron D. Coachman', 'RonDCoachman@teleworm.us', 3410),
(12, 'Andrew C. Cotta', 'AndrewCCotta@armyspy.com', 4220),
(13, 'David J. Gonzalez', 'DavidJGonzalez@armyspy.com', 86),
(14, 'Emma D. Justus', 'EmmaDJustus@jourrapide.com', 64),
(16, 'George M. Bowmano', 'GeorgeMBowman@armyspy.com', 149);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
