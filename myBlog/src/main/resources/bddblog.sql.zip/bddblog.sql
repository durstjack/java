-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Client: 127.0.0.1
-- Généré le: Mar 28 Juillet 2015 à 14:15
-- Version du serveur: 5.5.27
-- Version de PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `bddblog`
--

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(100) NOT NULL,
  `corps` varchar(900) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `posts`
--

INSERT INTO `posts` (`id`, `titre`, `corps`, `date`) VALUES
(3, 'Pellentesque ultrices a est dapibus curs', 'Aliquam erat volutpat. Interdum et malesuada fames ac ante ipsum primis in faucibus. Fusce vestibulum ligula id velit facilisis vulputate. Vivamus pulvinar ante eu porttitor blandit. Curabitur tempus ultrices dolor quis placerat. Nulla nec magna faucibus, dictum quam non, euismod nulla. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Praesent mattis lacus tortor, sed tempor nisl ultricies laoreet. Vestibulum mollis ligula ac nunc condimentum aliquet. Vivamus tristique molestie iaculis. Vivamus cursus rutrum velit. Nunc tempus, erat eu gravida fringilla, metus odio malesuada mi, sed sagittis justo urna a lorem. Nulla facilisi. Phasellus commodo imperdiet nisl, id egestas tellus euismod in. Aenean ac nisi vitae massa hendrerit laoreet. Nunc ', '2015-07-27'),
(5, 'Quisque eget ipsu', 'Quisque eget ipsum ultrices, aliquet sapien at, feugiat urna. Proin venenatis diam eu risus vulputate volutpat. Etiam semper, metus sit amet fringilla rutrum, elit sem pulvinar diam, eu dictum lorem odio ac ipsum. Integer condimentum id odio ut suscipit. Quisque id mollis mauris. Vestibulum finibus mauris nec nulla tempus dapibus. Duis neque mauris, congue in venenatis vitae, accumsan sed nisi. Praesent maximus tellus ac lacus pretium, sit amet vulputate justo consectetur.', '2015-07-27'),
(6, 'Cras iaculis fringilla just', 'Cras iaculis fringilla justo, eu interdum dolor vehicula a. Curabitur accumsan aliquam justo in consectetur. Curabitur ac mauris lacus. Nunc accumsan vitae augue sed ullamcorper. Nam volutpat vel libero id finibus. Etiam vitae orci consequat, mattis mauris eu, maximus magna. Morbi dignissim convallis mi eu ultrices. Vivamus nulla odio, dapibus vel urna tincidunt, ornare vehicula eros. Maecenas suscipit libero mi, hendrerit euismod mi viverra at. Quisque egestas mattis suscipit. Vestibulum sit amet enim at erat sollicitudin ultrices. \r\n\r\nCurabitur vitae rhoncus augue, ut lacinia quam. Donec placerat rhoncus mi, a molestie est. Vivamus vel porta mi, non pellentesque ante. Fusce arcu mi, molestie non consectetur eu, pellentesque nec tellu', '2015-07-27'),
(8, 'Plusieurs varia', 'Plusieurs variations de Lorem Ipsum peuvent être trouvées ici ou là, mais la majeure partie d''entre elles a été altérée par l''addition d''humour ou de mots aléatoires qui ne ressemblent pas une seconde à du texte standard. Si vous voulez utiliser un passage du Lorem Ipsum, vous devez être sûr qu''il n''y a rien d''embarrassant caché dans le texte. Tous les générateurs de Lorem Ipsum sur Internet tendent à reproduire le même extrait sans fin, ce qui fait de lipsum.com le seul vrai générateur de Lorem Ipsum. Iil utilise un dictionnaire de plus de 200 mots latins, en combinaison de plusieurs structures de phrases, pour générer un Lorem Ipsum ', '2015-07-28'),
(9, 'Kit Quad Channel DDR4 HyperX Fury', 'DDR4 Ultra performante et garantie à vie\r\n\r\nLe kit de mémoire HyperX® FURY DDR4 vous permet d''affronter les combats les plus durs. Il reconnaît automatiquement la plate-forme hôte et sélectionne la plus haute fréquence de surcadençage pour pouvoir déchaîner toute votre puissance sur vos adversaires.\r\n\r\nMême à sa fréquence maximale, la mémoire FURY DDR4 fonctionne à 1,2V et reste donc froide en toute circonstance. Vous n''avez pas besoin de modifier la tension pour atteindre des vitesses plus élevées, laissant l''alimentation libre pour d''autres éléments du système.\r\n\r\nLe dissipateur de chaleur asymétrique noir et élégant de la série Fury assure une dissipation thermique efficace et confère un design distinctif à ce Kit haute performance.', '2015-07-28');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
